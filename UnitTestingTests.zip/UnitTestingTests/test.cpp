#include "pch.h"
#include <vector>

TEST(ContainerTest, ValidFirstIndex)
{
    std::vector<int> numbers = { 10, 20, 30 };

    EXPECT_EQ(numbers.at(0), 10);
}

TEST(ContainerTest, ValidLastIndex)
{
    std::vector<int> numbers = { 10, 20, 30 };

    EXPECT_EQ(numbers.at(2), 30);
}

TEST(ContainerTest, IndexEqualToSizeThrows)
{
    std::vector<int> numbers = { 10, 20, 30 };

    EXPECT_THROW(numbers.at(3), std::out_of_range);
}

TEST(ContainerTest, NegativeIndexThrows)
{
    std::vector<int> numbers = { 10, 20, 30 };

    EXPECT_THROW(numbers.at(-1), std::out_of_range);
}

TEST(ContainerTest, LargeIndexThrows)
{
    std::vector<int> numbers = { 10, 20, 30 };

    EXPECT_THROW(numbers.at(100), std::out_of_range);
}